"""course identity from the first page or two."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from ..text.model import ExtractedDoc
from ..text.normalize import URL_RE, collapse_whitespace
from .dates import Term, find_term

# a course code is letters then digits, usually with a space between
CODE_RE = re.compile(r"\b([A-Z]{2,5})\s*[- ]?\s*(\d{3,5}[A-Z]?)\b")

# some syllabi never print the subject prefix and label the number instead:
# "Course Number: 4316", with the department on its own line. the number alone
# is a weaker label than "INTL 4316" but it is what the document actually says,
# and inventing the prefix from a department name would be a guess.
LABELLED_CODE_RE = re.compile(
    r"^\s*course\s*(?:number|code|no\.?)\s*[:#]\s*"
    r"(?P<code>[A-Z]{2,5}\s?\d{3,5}[A-Z]?|\d{3,5}[A-Z]?)\b",
    re.IGNORECASE | re.MULTILINE,
)
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")

_LABELLED = {
    "instructor": re.compile(
        r"^\s*(?:instructor|professor|taught by|lecturer)\s*:?\s*(?P<value>.+)$", re.IGNORECASE
    ),
    "email": re.compile(r"^\s*e-?mail\s*:?\s*(?P<value>.+)$", re.IGNORECASE),
    "time": re.compile(
        r"^\s*(?:time|class time|meeting time|meets|meeting times?(?: and location)?)\s*:?\s*(?P<value>.+)$",
        re.IGNORECASE,
    ),
    "location": re.compile(
        r"^\s*(?:place|location|room|classroom)\s*:?\s*(?P<value>.+)$", re.IGNORECASE
    ),
    "site": re.compile(
        r"^\s*(?:course (?:website|site|page|pages)|website)\s*:?\s*(?P<value>.+)$", re.IGNORECASE
    ),
}

# style guides a syllabus may require, overriding the personal default
_STYLE_RE = re.compile(
    r"\b(apsr|apa|mla|chicago|turabian|harvard|ieee|ama|bluebook|asa)\b", re.IGNORECASE
)


@dataclass
class CourseMeta:
    code: str | None = None
    title: str | None = None
    term: Term | None = None
    instructor_name: str | None = None
    instructor_email: str | None = None
    meeting_time: str | None = None
    location: str | None = None
    site_url: str | None = None
    citation_style: str | None = None
    confidence: float = 0.0
    raw: str = ""


# a term written into a filename: "Spring2026", "Fall_2026", "fa25 " is not
# attempted, only the full season word with no or thin separation
_FILENAME_TERM_RE = re.compile(r"(fall|spring|summer|winter)[\s_-]*(20\d{2})", re.IGNORECASE)


def find_term_in_document(doc: ExtractedDoc) -> Term | None:
    """look in the untouched page text.

    the term is very often printed in the running header, which header stripping
    removes on purpose, so the cleaned text is the wrong place to look for it.

    a term is printed at the front, so the first pages are asked first and a
    match there is taken over everything else.

    the filename comes next. two real syllabi carry their term nowhere else
    ("HIST1234_Ashe_Spring2026_..."), and with no term no year-less date in the
    document can be resolved at all. it used to come last, behind a scan of
    the whole document, and that scan is the problem: a season and year sit in
    every other bibliography entry, so a reading published in Summer 2016 made
    a syllabus taught in 2026 report itself as ten years old. a name the author
    typed is worth more than a publication date on page thirty.

    the whole-document scan is kept as the last resort, for a file named
    without a term whose own front matter never states one.
    """
    for page in doc.pages[:3]:
        found = find_term(page.raw_text) or find_term(page.text)
        if found:
            return found
    m = _FILENAME_TERM_RE.search(Path(str(doc.path)).name)
    if m:
        return Term(m.group(1).lower(), int(m.group(2)))
    return find_term(doc.text)


def parse(doc: ExtractedDoc) -> CourseMeta:
    head = "\n".join(page.raw_text for page in doc.pages[:2])
    meta = CourseMeta(raw=head)
    lines = [collapse_whitespace(line) for line in head.splitlines()]
    lines = [line for line in lines if line]

    meta.term = find_term_in_document(doc)

    code = CODE_RE.search(head)
    if code:
        meta.code = f"{code.group(1)} {code.group(2)}"
    else:
        labelled = LABELLED_CODE_RE.search(head)
        if labelled:
            meta.code = collapse_whitespace(labelled.group("code")).upper()

    meta.title = _find_title(lines, meta.code)

    values = _labelled_values(lines)
    meta.instructor_name = values.get("instructor")
    meta.meeting_time = values.get("time")
    meta.location = values.get("location")

    email = EMAIL_RE.search(head)
    if email:
        meta.instructor_email = email.group(0)
    if meta.instructor_name:
        meta.instructor_name = _plausible_name(
            EMAIL_RE.sub("", meta.instructor_name).strip(" ,;")
        )

    site = values.get("site") or ""
    url = URL_RE.search(site) or URL_RE.search(head)
    if url:
        meta.site_url = url.group(0).rstrip(".,;)")

    style = _STYLE_RE.search(head)
    if style:
        meta.citation_style = style.group(1).lower()

    meta.confidence = _score(meta)
    return meta


def _labelled_values(lines: list[str]) -> dict[str, str]:
    """read "label: value" pairs, including the two column layouts.

    some syllabi set the labels in one column and the values in another, which
    extracts as a label on its own line followed by its value on the next. an
    empty value therefore falls through to the following line.
    """
    found: dict[str, str] = {}
    for index, line in enumerate(lines):
        for key, pattern in _LABELLED.items():
            if key in found:
                continue
            m = pattern.match(line)
            if not m:
                continue
            value = _value_up_to_next_label(m.group("value").strip(" :-"), key)
            if not value and index + 1 < len(lines):
                value = _value_up_to_next_label(lines[index + 1].strip(" :-"), key)
            if value:
                found[key] = value
    return found


# the label words themselves, for finding where the next field starts inside a
# value. a header block set in two columns can arrive as one joined line, and
# then every field after the first is buried in the first one's value.
_NEXT_LABEL_RE = re.compile(
    r"\s+(?:instructor|professor|lecturer|e-?mail|time|class time|meeting times?|"
    r"meets|place|location|room|classroom|office hours?|course (?:website|site|page)|"
    r"website|phone|term|semester)\s*:",
    re.IGNORECASE,
)


def _value_up_to_next_label(value: str, key: str) -> str:
    """stop a value where the next field's label begins.

    "Instructor: Dana Okafor Time: Tues 2:00-4:45" on one line gave the
    instructor a name with the meeting time inside it, and left the meeting
    time unfound. the browser hits this and the command line does not, because
    the two split the header block differently.
    """
    m = _NEXT_LABEL_RE.search(value)
    return (value[: m.start()] if m else value).strip(" ,;:-")


# a person's name, roughly. the label patterns match prose that happens to open
# with one of their words, and the header now shows what they find, so a value
# that reads as a sentence, a rule of underscores or a bulleted question is
# dropped rather than printed as the person teaching the course.
_NOT_A_NAME_RE = re.compile(
    r"^[^A-Za-z]"          # a bullet or a dash opening it
    r"|_{3,}"              # a rule of underscores from a fill-in form
    r"|[?!]"               # a question is never a name
    r"|\b(?:will|may|must|should|please|failure|policy|policies|schedule|"
    r"necessary|antibiotics|consequences)\b",
    re.IGNORECASE,
)


def _plausible_name(value: str | None) -> str | None:
    """keep a value that could be a person, drop prose that matched the label.

    the label patterns catch any line opening with their word, so a sentence
    beginning "Instructor" or a bulleted question can arrive here. the record
    header prints whatever this returns, so a wrong answer is now visible.
    an honorific keeps its full stop: "Dr. Priya Raman" is a name.
    """
    if not value:
        return None
    # the brackets an email used to sit in, now empty
    text = re.sub(r"\(\s*\)", "", value).strip(" ,;")
    if not 3 <= len(text) <= 60:
        return None
    # a label that caught its own section heading rather than a person
    if re.fullmatch(r"(?:contact\s+)?information|drop-?in hours?|office hours?|"
                    r"details|staff|faculty", text, re.IGNORECASE):
        return None
    if len(text.split()) > 8:
        return None
    if _NOT_A_NAME_RE.search(text):
        return None
    # a full stop that is not an initial or an honorific ends a sentence
    if re.search(r"(?<![A-Z])(?<!\bDr)(?<!\bMr)(?<!\bMs)(?<!\bMrs)(?<!\bProf)\.\s+[A-Za-z]", text):
        return None
    if not re.search(r"[A-Za-z]{2,}", text):
        return None
    return text


_CONTINUES = re.compile(r"(?:\b(?:to|of|and|in|on|for|the|a|an)|[:,&-])$", re.IGNORECASE)


def _find_title(lines: list[str], code: str | None) -> str | None:
    """the most title-like line near the code, joined across wraps.

    a long title wraps in the header block, and each fragment alone looks
    incomplete, so a line that ends mid phrase pulls the following line in.
    """
    if code:
        bare = code.replace(" ", "")
        for index, line in enumerate(lines):
            if bare in line.replace(" ", ""):
                same_line = re.sub(re.escape(code), "", line, flags=re.IGNORECASE)
                same_line = same_line.strip(" :-–—")
                if len(same_line) > 6 and not _is_label(same_line):
                    return _join_wrapped(same_line, lines[index + 1:])
                for offset, candidate in enumerate(lines[index + 1: index + 4]):
                    if len(candidate) > 6 and not _is_label(candidate):
                        return _join_wrapped(
                            candidate.strip(" :-–—"), lines[index + offset + 2:]
                        )
    for line in lines[:6]:
        if len(line) > 10 and not _is_label(line) and not CODE_RE.search(line):
            return line
    return None


def _join_wrapped(title: str, rest: list[str]) -> str:
    for line in rest:
        if len(title) > 90 or not _CONTINUES.search(title):
            break
        candidate = line.strip(" :-–—")
        if not candidate or _is_label(candidate):
            break
        title = f"{title} {candidate}"
    return title.strip()


def _is_label(line: str) -> bool:
    if any(pattern.match(line) for pattern in _LABELLED.values()):
        return True
    return bool(EMAIL_RE.search(line) or URL_RE.search(line)) or find_term(line) is not None


def _score(meta: CourseMeta) -> float:
    have = [meta.code, meta.title, meta.term, meta.instructor_name]
    return round(sum(1 for value in have if value) / len(have), 3)
